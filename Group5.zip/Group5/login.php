<?php
session_start(); // Start the session

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $connection = mysqli_connect('localhost', 'root', '', 'mbstu');
    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users11 WHERE username = '$username' OR email = '$email'";
    $result = mysqli_query($connection, $query);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        if ($username === $user['username'] && $email === $user['email'] && $password === $user['password']) {
    
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];

            mysqli_close($connection);
            header("Location: profile.php"); 
            exit();
        } else {
            echo "Incorrect Username, Email, or Password";
        }
    } else {
        echo "User not found";
    }

    mysqli_close($connection);
}
?>
