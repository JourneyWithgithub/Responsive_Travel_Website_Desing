<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book</title>
    <link rel="icon" href="piegon.ico">

    <!---swiper css link-->

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css">

    <!--font awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <link rel="stylesheet" href="style.css">



    <script>
    document.addEventListener('DOMContentLoaded', function () {
        function toggleFAQ(index) {
            const faqItem = document.getElementById(`faq-item-${index}`);
            const faqAnswer = faqItem.querySelector('.faq-answer');

            if (faqItem.classList.contains('active')) {
                faqItem.classList.remove('active');
                faqAnswer.style.display = 'none';
            } else {
                faqItem.classList.add('active');
                faqAnswer.style.display = 'block';
            }
        }

        function addNewFAQ() {
            const faqContainer = document.querySelector('.faq-container');
            const newIndex = faqContainer.children.length / 2 + 1;

            const faqItem = document.createElement('div');
            faqItem.className = 'faq-item';
            faqItem.id = `faq-item-${newIndex}`;

            const faqQuestion = document.createElement('div');
            faqQuestion.className = 'faq-question';
            faqQuestion.innerHTML = `New Question ${newIndex} <i class="fas fa-plus-circle" onclick="toggleFAQ(${newIndex})"></i>`;
            faqQuestion.addEventListener('click', function () {
                toggleFAQ(newIndex);
            });

            const faqAnswer = document.createElement('div');
            faqAnswer.className = 'faq-answer';
            faqAnswer.innerHTML = `Answer to New Question ${newIndex}`;
            faqAnswer.style.display = 'none';

            faqItem.appendChild(faqQuestion);
            faqItem.appendChild(faqAnswer);

            faqContainer.appendChild(faqItem);
        }

        console.log("Script executed successfully!");
    });
</script>



</head>
<body>

<!--header section starts--->

<section class="header">

<a href="Home.php" class="logo">
        <img src="Logo.jpg" alt="Logo" class="logo-image">
        <span class="logo-name">Travel.</span>
    </a>
<nav class="navbar">

<a href="Home.php">Home</a>
<a href="about.php">about</a>
<a href="package.php">package</a>
<a href="book.php">book</a>
<a href="#" id="dark-mode-toggle" title="Switch to Dark Mode">
            <i class="fas fa-moon"></i>
        </a>
</nav>

<div id="menu-btn" class ="fas fa-bars"></div>


</section>

<!---header section ends---->


<div class="heading" style="background:url(FAQ.jpg)no-repeat">

<h1>Vacation FAQ</h1>
</div>






<!-- FAQ section -->
<div class="faq-container">
    <div class="faq-item" id="faq-item-1">
        <div class="faq-question" onclick="toggleFAQ(1)">
            HOW DO I CANCEL A TRIP?
            <i class="fas fa-plus-circle"></i>
        </div>
        <div class="faq-answer">
            You can cancel your trip by contacting our customer support. Please check our cancellation policy for details.
        </div>
    </div>

    <div class="faq-item" id="faq-item-2">
        <div class="faq-question" onclick="toggleFAQ(2)">
            HOW DO I KNOW I CAN TRUST THIS TRAVEL VENDOR?
            <i class="fas fa-plus-circle"></i>
        </div>
        <div class="faq-answer">
            We ensure that all our travel vendors are reputable and trustworthy. You can also check reviews from other travelers.
        </div>
    </div>

    <!-- Repeat the pattern for more questions and answers -->

</div>

<!-- New Question Button -->
<button class="new-question-btn" onclick="addNewFAQ()">Add New FAQ</button>





    <!-- Footer section starts -->
    <section class="footer">
      <div class="box-container">
        <div class="box">
          <h3>quick links</h3>
          <a href="home.php"><i class="fas fa-angle-right"></i>home</a>
          <a href="about.php"><i class="fas fa-angle-right"></i>about</a>
          <a href="package.php"><i class="fas fa-angle-right"></i>package</a>
          <a href="book.php"><i class="fas fa-angle-right"></i>book</a>
        </div>
        <div class="box">
          <h3>extra links</h3>
          <a href="#"><i class="fas fa-angle-right"></i>ask questions</a>
          <a href="#"><i class="fas fa-angle-right"></i>about us</a>
          <a href="#"><i class="fas fa-angle-right"></i>privacy policy</a>
          <a href="#"><i class="fas fa-angle-right"></i>terms of use</a>
        </div>
        <div class="box">
          <h3>contact info</h3>
          <a href="#"><i class="fas fa-phone"></i>+088-01781-941604</a>
          <a href="#"><i class="fas fa-phone"></i>+088-01781-941604</a>
          <a href="#"><i class="fas fa-phone"></i>+088-01640-941604</a>
          <a href="#"><i class="fas fa-envelope"></i>ce20044@mbstu.ac.bd</a>
          <a href="#"><i class="fas fa-map"></i>Dhaka, Bangladesh - 4001234</a>
        </div>
        <div class="box">
          <h3>follow us</h3>
          <a href="#"><i class="fab fa-facebook-f"></i>facebook</a>
          <a href="#"><i class="fab fa-twitter"></i>twitter</a>
          <a href="#"><i class="fab fa-instagram"></i>instagram</a>
          <a href="#"><i class="fab fa-linkedin"></i>linkedin</a>
        </div>
      </div>
      <div class="credit">created by <span>Jalil: Sandija: Shamim: Megla</span> | all rights reserved!</div>
    </section>
    <!-- Footer section ends -->


<!--Javascript file---->

<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>

<script src="script.js"></script>




    
</body>
</html>