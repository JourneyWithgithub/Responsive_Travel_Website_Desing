document.addEventListener('DOMContentLoaded', function() {
    const darkModeToggle = document.getElementById('dark-mode-toggle');
    const body = document.body;

    darkModeToggle.addEventListener('click', function() {
        body.classList.toggle('dark-mode');
    });

    
    darkModeToggle.addEventListener('mouseover', function() {
        darkModeToggle.title = 'Switch to Dark Mode';
    });

    darkModeToggle.addEventListener('mouseout', function() {
        darkModeToggle.title = '';
    });
});



let menu =document.querySelector('#menu-btn');
let navbar=document.querySelector('.header .navbar');

menu.onclick= ()=>
{
    menu.classList.toggle('fa-times');
    navbar.classList.toggle('active');

    
}

window.onscroll=()=>
{
    menu.classList.remove('fa-times');
    navbar.classList.remove('active');
};


var swiper= new Swiper(".home-slider",{
    loop: true,
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
});


var swiper = new Swiper(".review-slider", {
    loop: true,
    spaceBetween: 20,
    autoHeight: true,
    grabCursor: true,
    breakpoints: {
        640: {
            slidesPerView: 1,
        },
        768: {
            slidesPerView: 2,
        },
        1024: {
            slidesPerView: 3,
        },
    },
});

let loadMoreBtn = document.querySelector('.packages .load-more .btn');

let CurrentItem = 0;

loadMoreBtn.onclick = () => {
    let boxes = document.querySelectorAll('.packages .box-container .box');

    for (let i = CurrentItem; i < CurrentItem + 3; i++) {
        if (boxes[i]) {
            
            boxes[i].style.display = 'inline-block';
        }
    }

  
    CurrentItem += 3;

    if (CurrentItem >= boxes.length) {
        loadMoreBtn.style.display = 'none';
    }
};
function toggleLoginPopup() {
    var loginPopup = document.getElementById("loginPopup");
    loginPopup.style.display = (loginPopup.style.display === "none" || loginPopup.style.display === "") ? "block" : "none";
}

function toggleRegisterPopup() {
    var registerPopup = document.getElementById("registerPopup");
    registerPopup.style.display = (registerPopup.style.display === "none" || registerPopup.style.display === "") ? "block" : "none";
}

function closeLoginPopup() {
    var loginPopup = document.getElementById("loginPopup");
    loginPopup.style.display = "none";
}

function closeRegisterPopup() {
    var registerPopup = document.getElementById("registerPopup");
    registerPopup.style.display = "none";
}

function login() {
    const formData = new FormData(document.getElementById('loginForm')); 
    fetch('login.php', {
            method: 'POST',
            body: formData 
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === "Login Successful") {
                window.location.href = "profile.php"; 
            } else {
               
                alert(data.error);
            }
        })
        .catch(error => console.error('Error:', error));
}



function logout() {

    document.getElementById("loginPopup").style.display = "block";
    document.getElementById("profilePage").style.display = "none";
}

function register() {
    var newUsername = document.getElementById("newUsername").value;
    var newEmail = document.getElementById("newEmail").value;
    var newPassword = document.getElementById("newPassword").value;

    

    fetch('login.php', {
        method: 'POST',
        body: JSON.stringify({ newUsername: newUsername, newEmail: newEmail, newPassword: newPassword, register: true }),
        headers: {
            'Content-type': 'application/json; charset=UTF-8'
        }
    })
    .then(response => response.json())
    .then(data => {
        // Handle response from server
        console.log(data);
        
    })
    .catch(err => {
        console.error('Error:', err);
    });
}

// Function to create a modal with a message and an icon
function showModal(message) {
    const modal = document.createElement('div');
    modal.classList.add('modal');

    const modalContent = `
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <p>${message}</p>
        </div>
    `;

    modal.innerHTML = modalContent;
    document.body.appendChild(modal);
}

// Function to close the modal
function closeModal() {
    const modal = document.querySelector('.modal');
    modal.remove();
}


fetch('your_php_script.php', {
    method: 'POST',
    body: new FormData(document.querySelector('your_form_selector')),
})
.then(response => response.json())
.then(data => {
    if (data.message !== "") {
        showModal(data.message); 
        window.location.href = 'profile.php'; 
    }
})
.catch(error => {
    console.error('Error:', error);
});



const user = {
    username: "JohnDoe",
    email: "johndoe@example.com"
};

document.getElementById("usernameDisplay").innerText = user.username;
document.getElementById("emailDisplay").innerText = user.email;

function editProfile() {
    // Implement edit profile functionality here
    alert("Implement Edit Profile functionality");
}

function changePassword() {
    
    alert("Implement Change Password functionality");
}

function logout() {
    
    window.location.href = "index.html"; 
}

function togglePasswordVisibility(passwordFieldId) {
    const passwordField = document.getElementById(passwordFieldId);
    const eyeIcon = document.getElementById(passwordFieldId === 'password' ? 'loginEyeIcon' : 'registerEyeIcon');

    if (passwordField.type === 'password') {
        passwordField.type = 'text';
        eyeIcon.classList.remove('fa-eye');
        eyeIcon.classList.add('fa-eye-slash');
    } else {
        passwordField.type = 'password';
        eyeIcon.classList.remove('fa-eye-slash');
        eyeIcon.classList.add('fa-eye');
    }
}

function previewProfilePicture(event) {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = function () {
        const imgElement = document.getElementById('profileImg');
        imgElement.src = reader.result;
    };

    if (file) {
        reader.readAsDataURL(file);
    }
}

function showUploadButton() {
    document.getElementById('uploadInput').style.display = 'block';
}

function hideUploadButton() {
    document.getElementById('uploadInput').style.display = 'none';
}


document.addEventListener('DOMContentLoaded', function() {
    function calculateCost(event) {
        const arrivals = new Date(document.getElementsByName('arrivals')[0].value);
        const leavings = new Date(document.getElementsByName('leavings')[0].value);

        
        if (isNaN(arrivals) || isNaN(leavings)) {
            alert("Please enter valid arrival and leaving dates.");
            return;
        }

        const oneDay = 24 * 60 * 60 * 1000; 
        const diffTime = Math.abs(leavings - arrivals);
        const diffDays = Math.ceil(diffTime / oneDay); 

        const costPerDay = 1.00; // cost per day
        const totalCost = (diffDays * costPerDay).toFixed(2); // total cost

        document.getElementById('totalCost').innerText = `$${totalCost}`;
        document.getElementById('totalCost').classList.add('calculated');
    }

    
    document.getElementById('calculateBtn').addEventListener('click', calculateCost);
});



function toggleSection(sectionName) {
    
    
    if (sectionName === 'CurrencyConverter') {
      window.location.href = 'currency.php';
    }
    
  }
  
  
  document.addEventListener('DOMContentLoaded', function () {
    function toggleFAQ(index) {
        const faqItem = document.getElementById(`faq-item-${index}`);
        const faqAnswer = faqItem.querySelector('.faq-answer');

        faqAnswer.style.display = (faqAnswer.style.display === 'block') ? 'none' : 'block';
    }

    function addNewFAQ() {
        const faqContainer = document.querySelector('.faq-container');
        const newIndex = faqContainer.children.length + 1;

        const faqItem = document.createElement('div');
        faqItem.className = 'faq-item';
        faqItem.id = `faq-item-${newIndex}`;

        const faqQuestion = document.createElement('div');
        faqQuestion.className = 'faq-question';
        faqQuestion.innerHTML = `New Question ${newIndex} <i class="fas fa-plus-circle"></i>`;
        faqQuestion.addEventListener('click', function () {
            toggleFAQ(newIndex);
        });

        const faqAnswer = document.createElement('div');
        faqAnswer.className = 'faq-answer';
        faqAnswer.innerHTML = `Answer to New Question ${newIndex}`;
        faqAnswer.style.display = 'none';

        faqItem.appendChild(faqQuestion);
        faqItem.appendChild(faqAnswer);

        faqContainer.appendChild(faqItem);
    }

    console.log("Script executed successfully!");
});

function selectAvatar(avatar) {
    document.getElementById('selectedAvatar').value = avatar;

    
    $('.avatar').removeClass('selected');

    
    $('.avatar-' + avatar).addClass('selected');
}

