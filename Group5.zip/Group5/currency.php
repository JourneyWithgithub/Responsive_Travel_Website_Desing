<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book</title>
    <link rel="icon" href="piegon.ico">

    <!---swiper css link-->

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css">

    <!--font awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <link rel="stylesheet" href="style.css">


    

</head>
<body>

<!--header section starts--->

<section class="header">

<a href="Home.php" class="logo">
        <img src="Logo.jpg" alt="Logo" class="logo-image">
        <span class="logo-name">Travel.</span>
    </a>
<nav class="navbar">

<a href="Home.php">Home</a>
<a href="about.php">about</a>
<a href="package.php">package</a>
<a href="book.php">book</a>
<a href="#" id="dark-mode-toggle" title="Switch to Dark Mode">
            <i class="fas fa-moon"></i>
        </a>
</nav>

<div id="menu-btn" class ="fas fa-bars"></div>


</section>

<!---header section ends---->





<!-- Add this section within the <body> tag, before the closing </body> tag -->

<section class="currency-converter">
  <h2>Currency Converter</h2>
  <div>
    <label for="fromCurrency">From:</label>
    <select id="fromCurrency">
      <option value="taka">Taka</option>
      <option value="dollar">Dollar</option>
      <option value="euro">Euro</option>
      <option value="rupee">Rupee</option>
    </select>
  </div>
  <div>
    <label for="amount">Amount:</label>
    <input type="number" id="amount" placeholder="Enter amount" />
  </div>
  <div>
    <label for="toCurrency">To:</label>
    <select id="toCurrency">
      <option value="taka">Taka</option>
      <option value="dollar">Dollar</option>
      <option value="euro">Euro</option>
      <option value="rupee">Rupee</option>
    </select>
  </div>
  <button onclick="convertCurrency()">Convert</button>
  <p id="result"></p>
</section>

<script>
  function convertCurrency() {
    const fromCurrency = document.getElementById("fromCurrency").value;
    const toCurrency = document.getElementById("toCurrency").value;
    const amount = document.getElementById("amount").value;
    let convertedAmount;

    // Add your conversion logic here
    // Example: 1 Taka = 0.012 Dollar, 1 Taka = 0.011 Euro, 1 Taka = 0.94 Rupee
    switch (fromCurrency) {
      case "taka":
        convertedAmount = amount * (toCurrency === "dollar" ? 0.012 : toCurrency === "euro" ? 0.011 : 0.94);
        break;
      case "dollar":
        // Add conversion rates for other currencies if needed
        convertedAmount = amount * (toCurrency === "taka" ? 83.33 : 0);
        break;
      // Add cases for other currencies if needed
      default:
        convertedAmount = "Invalid conversion";
    }

    document.getElementById("result").innerText = `Converted Amount: ${convertedAmount.toFixed(2)} ${toCurrency.toUpperCase()}`;
  }
</script>







    <!-- Footer section starts -->
    <section class="footer">
      <div class="box-container">
        <div class="box">
          <h3>quick links</h3>
          <a href="home.php"><i class="fas fa-angle-right"></i>home</a>
          <a href="about.php"><i class="fas fa-angle-right"></i>about</a>
          <a href="package.php"><i class="fas fa-angle-right"></i>package</a>
          <a href="book.php"><i class="fas fa-angle-right"></i>book</a>
        </div>
        <div class="box">
          <h3>extra links</h3>
          <a href="#"><i class="fas fa-angle-right"></i>ask questions</a>
          <a href="#"><i class="fas fa-angle-right"></i>about us</a>
          <a href="#"><i class="fas fa-angle-right"></i>privacy policy</a>
          <a href="#"><i class="fas fa-angle-right"></i>terms of use</a>
        </div>
        <div class="box">
          <h3>contact info</h3>
          <a href="#"><i class="fas fa-phone"></i>+088-01781-941604</a>
          <a href="#"><i class="fas fa-phone"></i>+088-01781-941604</a>
          <a href="#"><i class="fas fa-phone"></i>+088-01640-941604</a>
          <a href="#"><i class="fas fa-envelope"></i>ce20044@mbstu.ac.bd</a>
          <a href="#"><i class="fas fa-map"></i>Dhaka, Bangladesh - 4001234</a>
        </div>
        <div class="box">
          <h3>follow us</h3>
          <a href="#"><i class="fab fa-facebook-f"></i>facebook</a>
          <a href="#"><i class="fab fa-twitter"></i>twitter</a>
          <a href="#"><i class="fab fa-instagram"></i>instagram</a>
          <a href="#"><i class="fab fa-linkedin"></i>linkedin</a>
        </div>
      </div>
      <div class="credit">created by <span>Jalil: Sandija: Shamim: Megla</span> | all rights reserved!</div>
    </section>
    <!-- Footer section ends -->


<!--Javascript file---->

<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>

<script src="script.js"></script>

    
</body>
</html>