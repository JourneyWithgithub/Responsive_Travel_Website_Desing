<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="icon" href="piegon.ico">

    <!---swiper css link-->

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css">

    <!--font awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <link rel="stylesheet" href="style.css">



    <style>

   



.logo {
    display: flex;
    align-items: center;
    text-decoration: none;
    color: #fff;
}

.logo-image {
    width: 40px; 
    margin-right: 10px;
}

.logo-name {
    font-size: 1.5em; 
}

.navbar {
    display: flex;
    align-items: center;
}

.navbar a {
    color: #fff;
    text-decoration: none;
    margin-right: 20px;
}

#dark-mode-toggle {
    color: #fff;
    cursor: pointer;
    margin-right: 20px;
}

.user-pic {
    width: 40px;
    border-radius: 50%;
    cursor: pointer;
    margin-right: 20px;
}

.sub-menu-wrap {
    position: absolute;
    top: 100%;
    right: 0;
    width: 320px;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.5s;
}

.sub-menu-wrap.open-menu {
    max-height: 400px;
}

.sub-menu {
    background: #fff;
    padding: 20px;
    margin: 10px;
}

.user-info {
    display: flex;
    align-items: center;
}

.user-info h2 {
    font-weight: 500;
    margin-left: 10px; 
}

.sub-menu-link {
    display: flex;
    align-items: center;
    text-decoration: none;
    color: #525252;
    margin: 12px 0;
}

.sub-menu-link p {
    width: 100%;
}

.sub-menu-link img {
    width: 40px;
    background: #e5e5e5;
    border-radius: 50%;
    padding: 8px;
    margin-right: 15px;
}

.sub-menu-link span {
    font-size: 22px;
    transition: transform 0.5s;
}

.sub-menu-link:hover span {
    transform: translateX(5px);
}

.sub-menu-link:hover p {
    font-weight: 600;
}

      </style>



</head>
<body>

<!--header section starts--->
<section class="header">
    <a href="Home.php" class="logo">
        <img src="Logo.jpg" alt="Logo" class="logo-image">
        <span class="logo-name">Travel.</span>
    </a>
    <nav class="navbar">
        <a href="Home.php">Home</a>
        <a href="about.php">about</a>
        <a href="package.php">package</a>
        <a href="book.php">book</a>
        <a href="#" id="dark-mode-toggle" title="Switch to Dark Mode">
            <i class="fas fa-moon"></i>
        </a>
        
      <!-- Profile dropdown -->
<div class="profile-dropdown">
    <img src="user.png" class="user-pic" onclick="toggleMenu()">
    <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-menu">
            <div class="user-info">
                <img src="user.png">
                <!-- Display the user's name from the session -->
                <?php
                session_start();
                if (isset($_SESSION['username'])) {
                    $username = $_SESSION['username'];
                    echo "<h2>$username</h2>";
                }
                ?>
            </div>
             <hr>
             <a href="EditProfile.php" class="sub-menu-link">
          <img src="profile.png">
    <p>Edit Profile</p>
    <span></span>
            </a>
      

                    <a href="#" class="sub-menu-link">
                        <img src="setting.png">
                        <p>Settings and Privacy</p>
                        <span></span>
                    </a>

                    <a href="logout.php" class="sub-menu-link">
    <img src="logout.png">
    <p>Logout</p>
    <span></span>
</a>

                </div>
            </div>
        </div>
    </nav>


    

    <div id="menu-btn" class="fas fa-bars"></div>
</section>




<!---header section ends---->


<div class="heading" style="background:url(profiteBackground.jpg)no-repeat">

<h1>Ready to explore?</h1>
</div>

<div class="additional-container" id="container1">
    <section class="additional-section" onclick="toggleSection('History')">
        <h2>History</h2>
        <i class="fas fa-history fa-3x"></i>
    </section>

    <section class="additional-section" onclick="toggleSection('WishList')">
        <h2>WishList</h2>
        <i class="fas fa-heart fa-3x"></i>
    </section>
</div>

<div class="additional-container" id="container2">
    <section class="additional-section" onclick="redirect('currency.php')">
        <h2>Currency Converter</h2>
        <i class="fas fa-dollar-sign fa-3x"></i>
    </section>


    <section class="additional-section" onclick="redirectToConversation()">
        <h2>Chat</h2>
        <i class="fas fa-comments fa-3x"></i>
    </section>
</div>


<div class="additional-container" id="container3">
    <section class="additional-section" onclick="redirect('Questions.php')">
        <h2>FAQ</h2>
        <i class="fas fa-question-circle fa-3x"></i>
    </section>

    <section class="additional-section" onclick="redirect('Transaction.php')">
        <h2>Transaction Gateway</h2>
        <i class="fas fa-money-bill-wave fa-3x"></i>
    </section>
</div>


<script>
  function redirectToConversation() {
    window.location.href = 'conversation.php';
  }

  function redirect(url) {
    window.location.href = url;
  }

  function toggleSection(section) {
    switch (section) {
      case 'History':
        
        break;
      case 'WishList':
        // Add logic for WishList section if needed
        break;
      case 'Chat':
        redirectToConversation();
        break;
      case 'FAQ':
        redirect('Questions.php'); 
        break;
      case 'Dashboard':
        
        break;
      default:
        console.error('Invalid section clicked');
    }
  }
</script>




<script>
  function toggleSection(sectionName) {
    if (sectionName === 'CurrencyConverter') {
      window.location.href = 'currency.php';
    }
    // Add conditions for other sections if needed
  }
</script>

<script>

let subMenu=document.getElementById("subMenu");

function toggleMenu()
{
  subMenu.classList.toggle("open-menu");
}
</script>



    <!-- Footer section starts -->
    <section class="footer">
      <div class="box-container">
        <div class="box">
          <h3>quick links</h3>
          <a href="home.php"><i class="fas fa-angle-right"></i>home</a>
          <a href="about.php"><i class="fas fa-angle-right"></i>about</a>
          <a href="package.php"><i class="fas fa-angle-right"></i>package</a>
          <a href="book.php"><i class="fas fa-angle-right"></i>book</a>
        </div>
        <div class="box">
          <h3>extra links</h3>
          <a href="#"><i class="fas fa-angle-right"></i>ask questions</a>
          <a href="#"><i class="fas fa-angle-right"></i>about us</a>
          <a href="#"><i class="fas fa-angle-right"></i>privacy policy</a>
          <a href="#"><i class="fas fa-angle-right"></i>terms of use</a>
        </div>
        <div class="box">
          <h3>contact info</h3>
          <a href="#"><i class="fas fa-phone"></i>+088-01781-941604</a>
          <a href="#"><i class="fas fa-phone"></i>+088-01781-941604</a>
          <a href="#"><i class="fas fa-phone"></i>+088-01640-941604</a>
          <a href="#"><i class="fas fa-envelope"></i>ce20044@mbstu.ac.bd</a>
          <a href="#"><i class="fas fa-map"></i>Dhaka, Bangladesh - 4001234</a>
        </div>
        <div class="box">
          <h3>follow us</h3>
          <a href="#"><i class="fab fa-facebook-f"></i>facebook</a>
          <a href="#"><i class="fab fa-twitter"></i>twitter</a>
          <a href="#"><i class="fab fa-instagram"></i>instagram</a>
          <a href="#"><i class="fab fa-linkedin"></i>linkedin</a>
        </div>
      </div>
      <div class="credit">created by <span>Jalil: Sandija: Shamim: Megla</span> | all rights reserved!</div>
    </section>
    <!-- Footer section ends -->


<!--Javascript file---->

<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>

<script src="script.js"></script>



    
</body>
</html>