<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $connection = mysqli_connect('localhost', 'root', '', 'mbstu');
    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $verificationCode = $_GET['code'];

    $query = "UPDATE users11 SET verified = 1 WHERE verification_code = '$verificationCode'";

    if (mysqli_query($connection, $query)) {
        echo "Email verification successful. You can now log in.";
    } else {
        echo "Email verification failed. Please contact support.";
    }

    mysqli_close($connection);
}
?>
