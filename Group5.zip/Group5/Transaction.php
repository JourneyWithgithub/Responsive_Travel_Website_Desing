<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book</title>
    <link rel="icon" href="piegon.ico">

    <!---swiper css link-->

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css">

    <!--font awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <link rel="stylesheet" href="style.css">

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            function calculateCost(event) {
                const arrivals = new Date(document.getElementsByName('arrivals')[0].value);
                const leavings = new Date(document.getElementsByName('leavings')[0].value);

                // Ensure both dates are valid
                if (isNaN(arrivals) || isNaN(leavings)) {
                    alert("Please enter valid arrival and leaving dates.");
                    return;
                }

                const oneDay = 24 * 60 * 60 * 1000; // milliseconds in a day
                const diffTime = Math.abs(leavings - arrivals);
                const diffDays = Math.ceil(diffTime / oneDay); // Round up to get the total days

                const costPerDay = 1.00; // cost per day
                const totalCost = (diffDays * costPerDay).toFixed(2); // total cost

                document.getElementById('totalCost').innerText = `$${totalCost}`; // Update the text
                document.getElementById('totalCost').classList.add('calculated'); // Add a class for styling
            }

            // Event listener for the button to calculate cost
            document.getElementById('calculateBtn').addEventListener('click', calculateCost);

            // Log a message to the console to check if the script is executed
            console.log("Script executed successfully!");
        });
    </script>
    
    

    <style>


/* Reset some default styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Body styles */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f8f8f8;
    color: #333;
    line-height: 1.6;
}


.logo {
    display: flex;
    align-items: center;
    justify-content: center;
}

.logo-image {
    width: 40px;
    height: 40px;
    margin-right: 10px;
}

/* Transaction gateway styles */
.transaction-gateway {
    max-width: 1200px;
    margin: 50px auto;
    text-align: center;
}

.transaction-gateway h1 {
    font-size: 36px;
    margin-bottom: 30px;
    color: #333;
}

.transaction-methods {
    display: flex;
    justify-content: center;
    gap: 20px;
    flex-wrap: wrap;
}

.transaction-method {
    cursor: pointer;
    background-color: #fff;
    border: 1px solid #ddd;
    padding: 20px;
    border-radius: 10px;
    transition: transform 0.3s;
}

.transaction-method img {
    max-width: 100px;
    max-height: 60px;
    margin-bottom: 10px;
}

.transaction-method:hover {
    transform: scale(1.05);
}

.user-information {
    margin-top: 30px;
    background-color: #fff;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
}

.user-information h2 {
    font-size: 24px;
    margin-bottom: 20px;
}

form {
    display: flex;
    flex-direction: column;
    max-width: 400px;
    margin: 0 auto;
}

label {
    font-size: 16px;
    margin-bottom: 8px;
    color: #333;
}

input {
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 16px;
}

button {
    background-color: #4caf50;
    color: #fff;
    padding: 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 1.2em;
    transition: background-color 0.3s;
}

button:hover {
    background-color: #45a049;
}

/* Footer styles */
.footer {
    background-color: #1a1a1a;
    color: #fff;
    padding: 30px 0;
    text-align: center;
}

.footer a {
    color: #fff;
}

/* Responsive styles */
@media screen and (max-width: 768px) {
    .transaction-methods {
        flex-direction: column;
        align-items: center;
    }

    .transaction-method {
        width: 100%;
        margin-bottom: 20px;
    }
}


      </style>

</head>
<body>

<!--header section starts--->

<section class="header">

<a href="Home.php" class="logo">
        <img src="Logo.jpg" alt="Logo" class="logo-image">
        <span class="logo-name">Travel.</span>
    </a>
<nav class="navbar">

<a href="Home.php">Home</a>
<a href="about.php">about</a>
<a href="package.php">package</a>
<a href="book.php">book</a>
<a href="#" id="dark-mode-toggle" title="Switch to Dark Mode">
            <i class="fas fa-moon"></i>
        </a>
</nav>

<div id="menu-btn" class ="fas fa-bars"></div>


</section>







<!-- Transaction gateway section starts -->
<section class="transaction-gateway">
    <h1>Select a Payment Method</h1>
    <div class="transaction-methods">
        <!-- Placeholder images and information -->
        <div class="transaction-method" onclick="proceedTransaction('Bkash')">
            <img src="Bkash.jpg" alt="Bkash">
            <p>Bkash</p>
        </div>
        <div class="transaction-method" onclick="proceedTransaction('Nagad')">
            <img src="nagad.png" alt="Nagad">
            <p>Nagad</p>
        </div>
        <div class="transaction-method" onclick="proceedTransaction('VisaCard')">
            <img src="visa.jpg" alt="Visa Card">
            <p>Visa Card</p>
        </div>
        <div class="transaction-method" onclick="proceedTransaction('Paypal')">
            <img src="paypal.png" alt="Paypal">
            <p>Paypal</p>
        </div>
        <div class="transaction-method" onclick="proceedTransaction('DBBL')">
            <img src="dbbl.jpg" alt="DBBL">
            <p>DBBL</p>
        </div>
    </div>

    <!-- User information form -->
    <div class="user-information">
        <h2>Provide Your Information</h2>
        <form id="transactionForm">
            <label for="fullName">Full Name:</label>
            <input type="text" id="fullName" name="fullName" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="phone">Phone Number:</label>
            <input type="tel" id="phone" name="phone" required>

            <button type="button" id="proceedBtn" onclick="proceedTransaction()">Proceed Transaction</button>
        </form>
    </div>
</section>
<!-- Transaction gateway section ends -->



    <!-- Footer section starts -->
    <section class="footer">
      <div class="box-container">
        <div class="box">
          <h3>quick links</h3>
          <a href="home.php"><i class="fas fa-angle-right"></i>home</a>
          <a href="about.php"><i class="fas fa-angle-right"></i>about</a>
          <a href="package.php"><i class="fas fa-angle-right"></i>package</a>
          <a href="book.php"><i class="fas fa-angle-right"></i>book</a>
        </div>
        <div class="box">
          <h3>extra links</h3>
          <a href="#"><i class="fas fa-angle-right"></i>ask questions</a>
          <a href="#"><i class="fas fa-angle-right"></i>about us</a>
          <a href="#"><i class="fas fa-angle-right"></i>privacy policy</a>
          <a href="#"><i class="fas fa-angle-right"></i>terms of use</a>
        </div>
        <div class="box">
          <h3>contact info</h3>
          <a href="#"><i class="fas fa-phone"></i>+088-01781-941604</a>
          <a href="#"><i class="fas fa-phone"></i>+088-01781-941604</a>
          <a href="#"><i class="fas fa-phone"></i>+088-01640-941604</a>
          <a href="#"><i class="fas fa-envelope"></i>ce20044@mbstu.ac.bd</a>
          <a href="#"><i class="fas fa-map"></i>Dhaka, Bangladesh - 4001234</a>
        </div>
        <div class="box">
          <h3>follow us</h3>
          <a href="#"><i class="fab fa-facebook-f"></i>facebook</a>
          <a href="#"><i class="fab fa-twitter"></i>twitter</a>
          <a href="#"><i class="fab fa-instagram"></i>instagram</a>
          <a href="#"><i class="fab fa-linkedin"></i>linkedin</a>
        </div>
      </div>
      <div class="credit">created by <span>Jalil: Sandija: Shamim: Megla</span> | all rights reserved!</div>
    </section>
    <!-- Footer section ends -->


<!--Javascript file---->

<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>

<script src="script.js"></script>

    
</body>
</html>