<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $connection = mysqli_connect('localhost', 'root', '', 'mbstu');
    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $newUsername = $_POST['newUsername'];
    $newEmail = $_POST['newEmail'];
    $newPassword = $_POST['newPassword'];

    // Hash the password
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    $query = "INSERT INTO users11 (username, email, password) VALUES ('$newUsername', '$newEmail', '$hashedPassword')";
    
    if (mysqli_query($connection, $query)) {
        // Registration successful
        mysqli_close($connection);
        echo json_encode(["message" => "Registration Successful"]);

        // Redirect to profile.php
        echo '<script>
                window.location.href = "profile.php";
              </script>';
    } else {
        // Registration failed
        echo json_encode(["error" => "Registration Failed"]);
    }

    mysqli_close($connection);
}
?>


