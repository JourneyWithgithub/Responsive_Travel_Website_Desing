<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book</title>
    <link rel="icon" href="piegon.ico">

    <!---swiper css link-->

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css">

    <!--font awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <link rel="stylesheet" href="style.css">


    <style>

body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
}

#chat-container {
    max-width: 600px;
    margin: 50px auto;
    padding: 20px;
    background-color: #fff;
    border: 1px solid #ccc;
    border-radius: 12px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
}

#message-list {
    list-style-type: none;
    padding: 0;
    margin: 0;
    overflow-y: scroll;
    max-height: 300px;
}

#message-list li {
    margin-bottom: 15px;
}

#message-input {
    width: calc(100% - 20px);
    padding: 12px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 12px;
    margin-top: 15px;
    font-size: 16px;
}

#send-button {
    background-color: #4caf50;
    color: white;
    padding: 12px 18px;
    border: none;
    border-radius: 12px;
    cursor: pointer;
    transition: background-color 0.3s;
    font-size: 16px;
}

#send-button:hover {
    background-color: #45a049;
}

/* Styling for user messages */
#message-list li:nth-child(odd) {
    background-color: #e1f5fe;
    padding: 12px;
    border-radius: 12px;
}


#message-list li:nth-child(even) {
    background-color: #c8e6c9;
    padding: 12px;
    border-radius: 12px;
}

#message-list li strong {
    margin-right: 10px;
    font-weight: bold;
}

#message-input:focus,
#send-button:focus {
    outline: none;
    border-color: #4caf50;
}


        </style>


</head>
<body>

<!--header section starts--->

<section class="header">

<a href="Home.php" class="logo">
        <img src="Logo.jpg" alt="Logo" class="logo-image">
        <span class="logo-name">Travel.</span>
    </a>
<nav class="navbar">

<a href="Home.php">Home</a>
<a href="about.php">about</a>
<a href="package.php">package</a>
<a href="book.php">book</a>
<a href="#" id="dark-mode-toggle" title="Switch to Dark Mode">
            <i class="fas fa-moon"></i>
        </a>
</nav>

<div id="menu-btn" class ="fas fa-bars"></div>


</section>

<!--header section --->





<section id="chat-container">
    <ul id="message-list"></ul>
    <input type="text" id="message-input" placeholder="Type your message...">
    <button id="send-button" onclick="sendMessage()">Send</button>
</section>


<script>
    function sendMessage() {
        const messageInput = document.getElementById('message-input');
        const messageList = document.getElementById('message-list');
        const messageText = messageInput.value.trim();

        if (messageText !== '') {
            const newMessage = document.createElement('li');
            newMessage.innerHTML = `<strong>User:</strong> ${messageText}`;
            messageList.appendChild(newMessage);

            // Simulate a reply after 1 second (you would replace this with a server-side reply)
            setTimeout(() => {
                const reply = document.createElement('li');
                reply.innerHTML = `<strong>Admin:</strong> Hello! How can I help you?`;
                messageList.appendChild(reply);
            }, 1000);

            // Clear the input field
            messageInput.value = '';

            // Scroll to the bottom of the message list
            messageList.scrollTop = messageList.scrollHeight;
        }
    }
</script>



    <!-- Footer section starts -->
    <section class="footer">
      <div class="box-container">
        <div class="box">
          <h3>quick links</h3>
          <a href="home.php"><i class="fas fa-angle-right"></i>home</a>
          <a href="about.php"><i class="fas fa-angle-right"></i>about</a>
          <a href="package.php"><i class="fas fa-angle-right"></i>package</a>
          <a href="book.php"><i class="fas fa-angle-right"></i>book</a>
        </div>
        <div class="box">
          <h3>extra links</h3>
          <a href="#"><i class="fas fa-angle-right"></i>ask questions</a>
          <a href="#"><i class="fas fa-angle-right"></i>about us</a>
          <a href="#"><i class="fas fa-angle-right"></i>privacy policy</a>
          <a href="#"><i class="fas fa-angle-right"></i>terms of use</a>
        </div>
        <div class="box">
          <h3>contact info</h3>
          <a href="#"><i class="fas fa-phone"></i>+088-01781-941604</a>
          <a href="#"><i class="fas fa-phone"></i>+088-01781-941604</a>
          <a href="#"><i class="fas fa-phone"></i>+088-01640-941604</a>
          <a href="#"><i class="fas fa-envelope"></i>ce20044@mbstu.ac.bd</a>
          <a href="#"><i class="fas fa-map"></i>Dhaka, Bangladesh - 4001234</a>
        </div>
        <div class="box">
          <h3>follow us</h3>
          <a href="#"><i class="fab fa-facebook-f"></i>facebook</a>
          <a href="#"><i class="fab fa-twitter"></i>twitter</a>
          <a href="#"><i class="fab fa-instagram"></i>instagram</a>
          <a href="#"><i class="fab fa-linkedin"></i>linkedin</a>
        </div>
      </div>
      <div class="credit">created by <span>Jalil: Sandija: Shamim: Megla</span> | all rights reserved!</div>
    </section>
    <!-- Footer section ends -->


<!--Javascript file---->

<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>

<script src="script.js"></script>

    
</body>
</html>