<?php

if (isset($_POST['send'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $location = $_POST['location'];
    $guests = $_POST['guests'];
    $arrivals = $_POST['arrivals'];
    $leaving = $_POST['leavings'];

    // Prepare data for the API request
    $data = [
        'name' => $name,
        'email' => $email,
        'phone' => $phone,
        'address' => $address,
        'location' => $location,
        'guests' => $guests,
        'arrivals' => $arrivals,
        'leavings' => $leaving,
    ];

    // Convert data to JSON
    $payload = json_encode($data);

    // URL of your REST API endpoint
    $api_url = 'http://localhost/RestAPI/customer/create.php';

    // Set up cURL to make the POST request to the API
    $curl = curl_init($api_url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

    // Execute the cURL request and capture the response
    $response = curl_exec($curl);

   
    if ($response === false) {
        echo 'Error: ' . curl_error($curl);
    } else {
        $decoded_response = json_decode($response, true);
        if (isset($decoded_response['status']) && $decoded_response['status'] === 200) {
            header('location: book.php');
        } else {
            echo 'Something went wrong with the API request';
        }
    }

    // Close cURL session
    curl_close($curl);
} else {
    echo 'Form submission error';
}
?>
