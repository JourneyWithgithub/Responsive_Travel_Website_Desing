<?php
// Check if the user is logged in
session_start();
if (!isset($_SESSION['username'])) {
    // Redirect to login page if not logged in
    header("Location: login.php"); // Change to your login page
    exit();
}

// Handle the profile editing logic here
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle the selected avatar
    $selectedAvatar = $_POST['selectedAvatar'];

    // Handle the uploaded file
    if (!empty($_FILES['profilePicture']['name'])) {
        // Set a unique filename for the uploaded file (e.g., user_<username>.png)
        $newProfilePicture = "user_" . $_SESSION['username'] . ".png";
        $uploadDirectory = "path/to/upload/directory/" . $newProfilePicture; // Change the path accordingly

        // Move the uploaded file to the desired directory
        move_uploaded_file($_FILES['profilePicture']['tmp_name'], $uploadDirectory);

        // Update the profile picture in the database or file system
        // (You need to implement your logic here)

        // Redirect back to the profile page after processing
        header("Location: profile.php"); // Change to your profile page
        exit();
    }

    // Handle the logic for updating the profile picture based on the selected avatar
    // (You need to implement your logic here)

    // Redirect back to the profile page after processing
    header("Location: profile.php"); // Change to your profile page
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <!-- Add jQuery library -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-bottom: 20px;
            cursor: pointer;
        }

        .avatar-container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        .avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            margin: 5px;
            cursor: pointer;
        }

        .avatar:hover {
            border: 2px solid #007bff; /* Highlight on hover */
        }

        /* Additional avatars */
        .avatar-cat {
            background-color: #ffcccb;
            mask: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23ffcccb"><path d="M0 0h24v24H0z"/></svg>') no-repeat;
            mask-size: cover;
        }

        .avatar-sunglasses {
            background-color: #d3d3d3;
            mask: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23d3d3d3"><path d="M0 0h24v24H0z"/></svg>') no-repeat;
            mask-size: cover;
        }

        .avatar-football {
            background-color: #add8e6;
            mask: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23add8e6"><path d="M0 0h24v24H0z"/></svg>') no-repeat;
            mask-size: cover;
        }

        .avatar-flower {
            background-color: #90ee90;
            mask: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%2390ee90"><path d="M0 0h24v24H0z"/></svg>') no-repeat;
            mask-size: cover;
        }

        .avatar-bird {
            background-color: #ffd700;
            mask: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23ffd700"><path d="M0 0h24v24H0z"/></svg>') no-repeat;
            mask-size: cover;
        }

        .avatar.selected {
    border: 2px solid #007bff; /* Highlight on selection */
}

    </style>
</head>

<body>
    <form action="EditProfile.php" method="post" enctype="multipart/form-data">
        <h1>Edit Profile</h1>
        <!-- Display the dynamically changing profile picture -->
        <div>
            <img src="user.png" class="expert-img" id="profileImage">
        </div>
        <div class="upload-button">Upload Image</div>
        <input class="file-upload" type="file" accept="image/*" name="profilePicture" id="fileInput">

        <hr>

        <label for="avatar">Choose an avatar:</label>
        <div class="avatar-container">
            <!-- Add unique identifiers to avatars -->
            <div class="avatar avatar-cat" onclick="selectAvatar('cat')"></div>
            <div class="avatar avatar-sunglasses" onclick="selectAvatar('sunglasses')"></div>
            <div class="avatar avatar-football" onclick="selectAvatar('football')"></div>
            <div class="avatar avatar-flower" onclick="selectAvatar('flower')"></div>
            <div class="avatar avatar-bird" onclick="selectAvatar('bird')"></div>
        </div>


        <hr>

        <button type="submit">Save Changes</button>
    </form>

    <script>
        // JavaScript function to set the selected avatar value
        function selectAvatar(avatar) {
            document.getElementById('selectedAvatar').value = avatar;
        }

        // jQuery script to handle file input change event and update the profile image
        $(function(){
            $('.file-upload').change(function(e) {
                var img = URL.createObjectURL(e.target.files[0]);
                $('#profileImage').attr('src', img);
            });

            $(".upload-button").on('click', function() {
                $(".file-upload").click();
            });
        });
    </script>
</body>