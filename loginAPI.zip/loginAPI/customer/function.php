

<?php

require '../inc/dbcon.php';

function error422($message)
{
    $data = [
        'status'=> 422,
        'message' => $message,


    ];

    header ("HTTP/1.0 422 Unprocessable Entity");

    echo json_encode($data);

    exit();
}


function storeCustomer($customerInput)
{
    global $conn;


    //$id = mysqli_real_escape_string($conn, $customerInput["id"]);

    $username = mysqli_real_escape_string($conn, $customerInput["username"]);
    $email = mysqli_real_escape_string($conn, $customerInput["email"]);
    $password = mysqli_real_escape_string($conn, $customerInput["password"]);
   
    

    if (empty(trim($username))) {
        return error422('Enter your username');
    } elseif (empty(trim($email))) {
        return error422('Enter your email');
    } elseif (empty(trim($password))) {
        return error422('Enter your password');
    } 
  
    

    
    
    else {
        $query = "INSERT INTO users11 (username,email, password) VALUES ('$username', '$email', '$password')";
        $result = mysqli_query($conn, $query);

        if ($result) {
            $data = [
                'status' => 201,
                'message' => 'user created successfully',
            ];

            header("HTTP/1.0 201 Created");

            return json_encode($data);
        } else {
            $data = [
                'status' => 500,
                'message' => 'Internal Server Error',
            ];

            header("HTTP/1.0 500 Internal Server Error");

            return json_encode($data);
        }
    }
}

function getCustomerList()
{

    global $conn;

    $query ="select * from users11";
    $query_run =mysqli_query($conn, $query);

    if($query_run)
    {
        if(mysqli_num_rows($query_run)>0)
        {

            $res = mysqli_fetch_all($query_run, MYSQLI_ASSOC);
            $data = [
                'status'=> 200,
                'message' => 'user List Fetched Successfully',
                'data' => $res
        
        
            ];
        
            header ("HTTP/1.0 200 user List Fetched Successfully");
        
            return json_encode($data);

        }
        else
        {
            $data = [
                'status'=> 404,
                'message' => 'No user Found',
        
        
            ];
        
            header ("HTTP/1.0 404 No user Found");
        
            return json_encode($data);
        }

    }

    else
    {
        $data = [
            'status'=> 500,
            'message' => 'Internal Server Error',
    
    
        ];
    
        header ("HTTP/1.0 500 Internal Server Error");
    
        return json_encode($data);
    }
}


 function getCustomer($customerParams)
 {
    global $conn;

    if($customerParams['id']==null)
    {
        return error422('Enter your user id');
    }

    $customerId= mysqli_real_escape_string($conn, $customerParams['id']);

    $query = "Select * from users11 WHERE id = '$customerId' LIMIT 1";

    $result = mysqli_query($conn, $query);     

    if($result)
    {

      if(mysqli_num_rows($result)==1)
      {
          $res = mysqli_fetch_assoc($result);

          $data = [
            'status'=> 200,
            'message' => 'user Fetched Successfully',
            'data' => $res
                ];
    
        header ("HTTP/1.0 200 Ok ");
    
        return json_encode($data);
      }
      else
      {
        $data = [
            'status'=> 404,
            'message' => 'No user Found',
    
    
        ];
    
        header ("HTTP/1.0 404 Not Found");
    
        return json_encode($data);
      }
    }
    else

    {

        $data = [
            'status'=> 500,
            'message' => 'Internal Server Error',
    
    
        ];
    
        header ("HTTP/1.0 500 Internal Server Error");
    
        return json_encode($data);
    }

 


 }    


 function updateCustomer($customerInput, $customerParams)
{
    global $conn;

    if(!isset($customerParams['id']))
    {
         return error422('client id not found in URL');
    }
    else if(($customerParams['id']==null))
    {
          return error422('Enter client id');
    }


    $customerId = mysqli_real_escape_string($conn, $customerInput['id']);
    $username = mysqli_real_escape_string($conn, $customerInput['username']);
    $email = mysqli_real_escape_string($conn, $customerInput['email']);
    $password = mysqli_real_escape_string($conn, $customerInput['password']);
     


    if (empty(trim($username))) {
        return error422('Enter your username');
    } 
    elseif (empty(trim($email))) {
        return error422('Enter your email');
    } elseif (empty(trim($password))) {
        return error422('Enter your password');
    } 
    
   

  
    
    
    
    else {
        $query = "update users11 set  username='$username', email='$email', password='$password' where id='$customerId' LIMIT 1";
        $result = mysqli_query($conn, $query);

        if ($result) {
            $data = [
                'status' => 200,
                'message' => 'user Updated successfully',
            ];

            header("HTTP/1.0 200 Successfully");

            return json_encode($data);
        } else {
            $data = [
                'status' => 500,
                'message' => 'Internal Server Error',
            ];

            header("HTTP/1.0 500 Internal Server Error");

            return json_encode($data);
        }
    }
}

function deleteCustomer($customerParams)
{
    global $conn;

    if(!isset($customerParams['id']))
    {
         return error422('user name not found in URL');
    }
    else if(($customerParams['id']==null))
    {
          return error422('Enter user name');
    }


    $customerId = mysqli_real_escape_string($conn, $customerParams['id']);  

    $query = "Delete from users11 where id= '$customerId' LIMIT 1";

    $result = mysqli_query($conn, $query);

    if($result)
    {
        $data = [
            'status' => 200,
            'message' => 'user deleted Successfully',
        ];

        header("HTTP/1.0 200 Deleted");

        return json_encode($data);
    }
    else
    { 

        $data = [
            'status' => 404,
            'message' => 'user Not Found',
        ];

        header("HTTP/1.0 404 Not Found");

        return json_encode($data);

    }

}
?>