



<?php

$host="localhost";
$username="root";
$password="";

$dbname="mbstu";

$conn= mysqli_connect($host,$username,$password,$dbname);

if(!$conn)
{
    die("Not Connected".mysqli_connect_errno());
}


?>